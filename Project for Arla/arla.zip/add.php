<?php header('Content-Type: text/html; charset=utf-8'); ?>

<html>
    <head>
        <title>Uopfordret ansøgning</title>
        <!-- Latest compiled and minified CSS -->
        <link rel="stylesheet" href="bootstrap/css/bootstrap-theme.min.css">
        <link rel="stylesheet" href="bootstrap/css/bootstrap.min.css">
        <!-- Optional theme -->

        <link rel="stylesheet" type="text/css" href="add.css">
        <!-- jQuery (necessary for Bootstrap's JavaScript plugins) -->
        <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.0/jquery.min.js"></script>
        <!-- Include all compiled plugins (below), or include individual files as needed -->
        <script src="bootstrap/js/bootstrap.min.js"></script>
    </head>

    <body style="margin-left: 20px;">
        <h1> Udfyld felterne nedenfor </h1>

        <div class="mainContainer">
            <form id="application" style="position: relative" action="insert.php" method="GET">
                <fieldset>
                    <legend>Personlige oplysninger</legend>
                    <div class="inputline"><p>Navn</p><input class="span3" placeholder="Dit navn her" type="text" name="name"/></div>
                    <div class="inputline"><p>Adresse</p><input type="text" name="address"/> </div>
                    <div class="inputline"><p>Postnummer</p><input type="text" name="postal"/> </div>
                    <div class="inputline"><p>By</p><input type="text" name="city"/> </div>
                    <div class="inputline"><p>Telefon nr</p><input type="text" name="telephone"/> </div>
                    <div class="inputline"><p>E-mail</p><input type="text" name="email"/> </div>
                    <div class="inputline"><p>Kommune</p><input type="text" name="munipicial"/> </div>
                    <div class="inputline"><p>Ryger du på arbejdet?</p><input type="checkbox" value='1' name="smoker"/> </div>
                </fieldset>
                <fieldset>
                    <legend>Erfaringer</legend>
                    <div class="inputline"><p>Tidligere skole(r)</p><input type="text" name="school"/> </div>
                    <div class="inputline"><p>Tidligere jobs</p><input type="text" name="earlierjobs"/> </div>
                    <div class="inputline"><p>Har du truck certifikat?</p><input value='1' type="checkbox" name="truckcert"/> </div>
                    <div class="inputline"><p>Har du et hygeine bevis?</p><input value='1' type="checkbox" name="cleancert"/> </div>
                    <div class="inputline"><p>Kender du SAP?</p><input value='1' type="checkbox" name="knowsap"/> </div>
                    <div class="inputline"><p>Kender du LEAN?</p><input value='1' type="checkbox" name="knowlean"/> </div>
                    <div class="inputline"><p>Kan du snakke engelsk ?</p><input value='1' type="checkbox" name="knowenglish"/> </div>
                    <div class="inputline"><p>Kan du læse engelsk ?</p><input value='1' type="checkbox" name="knowenglishtext"/> </div>
                </fieldset>
                <fieldset>
                    <legend>Arbejdsmuligheder</legend>
                    <div class="inputline"><p>En kort beskrivelse af dig som person</p><textarea  name="personaldescription"></textarea> </div>
                    <div class="inputline"><p>Hvorfor skal vi hyrer dig?</p><textarea name="hirereason"></textarea> </div>
                    <div class="inputline"><p>Hvornår kan du tidligst tiltræde?</p><input style="height: 50px;top: -00px" type="date" name="readydate"/> </div>
                    <p style="margin-left:20px;margin-top:20px;">Hvad former for arbejdstider kan du? (ferie, weekend, hverdage)</p> 
                    <div class="inputline inputlineIndented" ><p>Ferieafløser</p><input value='1'  type="checkbox" name="vacationdays"/> </div>
                    <div class="inputline inputlineIndented" ><p>Weekendafløser</p><input value='1' type="checkbox" name="weekendays"/> </div>
                    <div class="inputline inputlineIndented" ><p>Fuldtidsarbejde</p><input value='1' type="checkbox" name="usualdays"/> </div>

                    <div class="inputline"><p>Dag</p><input value='1' type="checkbox" name="day"/> </div>
                    <div class="inputline"><p>Nat</p><input value='1' type="checkbox" name="night"/> </div>
                </fieldset>
                <fieldset> 
                    <legend> Tidligere ansat </legend>
                    <div class="inputline"><p>Har du arbejdet hos arla før ?</p><input value='1' type="checkbox" name="prevarla"/> </div>
                    <div class="inputline"><p>Hvis ja, hvor?</p><input type="text" name="prevarlawhere"/> </div>
                    <div class="inputline"><p>Og med hvad?</p><input type="text" name="prevarlawhat"/> </div>
                </fieldset>
                
                
                <h3> Ved at klikke Send , giver du din samtrykke til, at disse oplysninger kan opbevares i 12 måneder fra dagens dato med henblik på evt. fremtidige ansæggelse.</h3>
                <input class="btn btn-primary" type="submit" value="Send ansøgning"/>
            </form>
        </div>
    </body>
</html>
