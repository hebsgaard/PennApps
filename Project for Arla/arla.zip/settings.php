<?php
include_once 'datastructures.php';
$mysqli =  new \mysqli("localhost", "root", "minkode23", "arla_app");

header('Content-Type: text/html; charset=utf-8');

