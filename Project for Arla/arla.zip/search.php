<link rel="stylesheet" type="text/css" href="review.css">
<h2> Søg her</h2>
<hr>
<form method="GET" action="review.php">
    <div class="reviews">
        <p>SAP</p><input type="checkbox"  name="ssap" <?php mc($ssap) ?> value="1"/>
        <p>Truck certifikat</p><input type="checkbox" <?php mc($truck) ?> name="truck"  value="1"/>
        <p>Hygiejne bevis</p><input type="checkbox" <?php mc($hyg) ?> name="hyg"  value="1"/>
        <p>Weekend </p><input type="checkbox" <?php mc($weekend) ?> name="weekend" value="1"/>
        <p>Hverdage</p><input type="checkbox" <?php mc($everyday )?> name="everyday"  value="1"/><br>
        <p>Ferie</p><input type="checkbox" <?php mc($vacation) ?> name="vacation" value="1"/>
        <p>LEAN</p><input type="checkbox" <?php mc($lean) ?> name="lean"  value="1"/>
        <p>Dag</p><input type="checkbox" <?php mc($day ) ?> name="day"  value="1"/>
        <p>Nat</p><input type="checkbox" <?php mc($night) ?> name="night"  value="1"/>
        <p>Faglært</p><input type="checkbox" <?php mc($job ) ?> name="job"  value="1"/><br>
        <p>Ryger på arbejdet</p><input type="checkbox" <?php mc($smoke) ?> name="smoke"  value="1"/>
        <p>Kan engelsk</p><input type="checkbox" name="eng" <?php mc($eng) ?> value="1"/>
        <p>Arbejdet hos arla før?</p><input type="checkbox" <?php mc($prev) ?> name="prevarla"  value="1"/>
        <p>Nærmeste tiltrædningsdato</p><input type="date" name="date" value="<?php dt($date)?>"/>
        <br>
    </div>
    <input type="submit" value="søg"/>
</form>
<form action="review.php?">
    <input type="submit" value="nulstil søging"/>
</form>
<hr>